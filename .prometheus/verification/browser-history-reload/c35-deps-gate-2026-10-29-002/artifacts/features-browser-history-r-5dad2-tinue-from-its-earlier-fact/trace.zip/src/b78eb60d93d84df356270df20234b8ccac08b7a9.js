// Generated from: features/browser-history-reload.feature
import { test } from "../../../scripts/behaviors/browser/browser-history-reload.steps.mjs";

test.describe('A browser conversation reloads from saved history', () => {

  test('Reopen a saved conversation after reload and continue from its earlier fact', { tag: ['@ui', '@conversation', '@reload'] }, async ({ Given, When, Then, And, page, scenario }) => { 
    await Given('a disposable custom agent is selected in a fresh browser conversation', null, { page, scenario }); 
    await When('I give the agent a fresh fact in the browser', null, { page, scenario }); 
    await And('I reload the page and reopen that conversation from the thread list', null, { page, scenario }); 
    await Then('the reopened conversation shows the saved turns without a new run', null, { page, scenario }); 
    await When('I send a follow-up that contains none of the earlier facts', null, { page, scenario }); 
    await Then('the follow-up answer uses the earlier fact from the saved server history', null, { page, scenario }); 
  });

});

// == technical section ==

test.use({
  $test: [({}, use) => use(test), { scope: 'test', box: true }],
  $uri: [({}, use) => use('features/browser-history-reload.feature'), { scope: 'test', box: true }],
  $bddFileData: [({}, use) => use(bddFileData), { scope: "test", box: true }],
});

const bddFileData = [ // bdd-data-start
  {"pwTestLine":6,"pickleLine":3,"tags":["@ui","@conversation","@reload"],"steps":[{"pwStepLine":7,"gherkinStepLine":4,"keywordType":"Context","textWithKeyword":"Given a disposable custom agent is selected in a fresh browser conversation","stepMatchArguments":[]},{"pwStepLine":8,"gherkinStepLine":5,"keywordType":"Action","textWithKeyword":"When I give the agent a fresh fact in the browser","stepMatchArguments":[]},{"pwStepLine":9,"gherkinStepLine":6,"keywordType":"Action","textWithKeyword":"And I reload the page and reopen that conversation from the thread list","stepMatchArguments":[]},{"pwStepLine":10,"gherkinStepLine":7,"keywordType":"Outcome","textWithKeyword":"Then the reopened conversation shows the saved turns without a new run","stepMatchArguments":[]},{"pwStepLine":11,"gherkinStepLine":8,"keywordType":"Action","textWithKeyword":"When I send a follow-up that contains none of the earlier facts","stepMatchArguments":[]},{"pwStepLine":12,"gherkinStepLine":9,"keywordType":"Outcome","textWithKeyword":"Then the follow-up answer uses the earlier fact from the saved server history","stepMatchArguments":[]}]},
]; // bdd-data-end