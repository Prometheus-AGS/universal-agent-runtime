// Generated from: features/browser-agent-selection.feature
import { test } from "../../../scripts/behaviors/browser/browser-agent-selection.steps.mjs";

test.describe('The browser shows orchestrator agent selection before the answer', () => {

  test('A writing task and then a math task show each selected specialist first', { tag: ['@ui', '@orchestrator', '@routing'] }, async ({ Given, When, Then, And, page, scenario }) => { 
    await Given('the saved math and writing specialists and an orchestrator conversation in the browser', null, { page, scenario }); 
    await When('I send a writing task in that conversation through the browser', null, { page, scenario }); 
    await Then('the browser shows the writing specialist selection before its specialist answer', null, { page, scenario }); 
    await When('I send a math task in the same conversation through the browser', null, { page, scenario }); 
    await Then('the browser shows the math specialist selection before its specialist answer', null, { page, scenario }); 
    await And('each selected specialist matches execution with no duplicate answer or run', null, { page, scenario }); 
  });

});

// == technical section ==

test.use({
  $test: [({}, use) => use(test), { scope: 'test', box: true }],
  $uri: [({}, use) => use('features/browser-agent-selection.feature'), { scope: 'test', box: true }],
  $bddFileData: [({}, use) => use(bddFileData), { scope: "test", box: true }],
});

const bddFileData = [ // bdd-data-start
  {"pwTestLine":6,"pickleLine":3,"tags":["@ui","@orchestrator","@routing"],"steps":[{"pwStepLine":7,"gherkinStepLine":4,"keywordType":"Context","textWithKeyword":"Given the saved math and writing specialists and an orchestrator conversation in the browser","stepMatchArguments":[]},{"pwStepLine":8,"gherkinStepLine":5,"keywordType":"Action","textWithKeyword":"When I send a writing task in that conversation through the browser","stepMatchArguments":[]},{"pwStepLine":9,"gherkinStepLine":6,"keywordType":"Outcome","textWithKeyword":"Then the browser shows the writing specialist selection before its specialist answer","stepMatchArguments":[]},{"pwStepLine":10,"gherkinStepLine":7,"keywordType":"Action","textWithKeyword":"When I send a math task in the same conversation through the browser","stepMatchArguments":[]},{"pwStepLine":11,"gherkinStepLine":8,"keywordType":"Outcome","textWithKeyword":"Then the browser shows the math specialist selection before its specialist answer","stepMatchArguments":[]},{"pwStepLine":12,"gherkinStepLine":9,"keywordType":"Outcome","textWithKeyword":"And each selected specialist matches execution with no duplicate answer or run","stepMatchArguments":[]}]},
]; // bdd-data-end