// Generated from: features/a2ui-browser.feature
import { test } from "../../../scripts/behaviors/browser/a2ui-browser.steps.mjs";

test.describe('Interact with a real A2UI response in the browser', () => {

  test('A rendered calculator sends fresh input back to its agent', { tag: ['@ui', '@a2ui'] }, async ({ Given, When, Then, page, scenario }) => { 
    await Given('a disposable A2UI calculator agent is selected in the browser', null, { page, scenario }); 
    await When('I ask the agent to render its calculator', null, { page, scenario }); 
    await Then('the browser displays the generated input and action button', null, { page, scenario }); 
    await When('I enter a fresh number and press the rendered calculate button', null, { page, scenario }); 
    await Then('the agent answers using that browser input and its saved instructions', null, { page, scenario }); 
  });

});

// == technical section ==

test.use({
  $test: [({}, use) => use(test), { scope: 'test', box: true }],
  $uri: [({}, use) => use('features/a2ui-browser.feature'), { scope: 'test', box: true }],
  $bddFileData: [({}, use) => use(bddFileData), { scope: "test", box: true }],
});

const bddFileData = [ // bdd-data-start
  {"pwTestLine":6,"pickleLine":3,"tags":["@ui","@a2ui"],"steps":[{"pwStepLine":7,"gherkinStepLine":4,"keywordType":"Context","textWithKeyword":"Given a disposable A2UI calculator agent is selected in the browser","stepMatchArguments":[]},{"pwStepLine":8,"gherkinStepLine":5,"keywordType":"Action","textWithKeyword":"When I ask the agent to render its calculator","stepMatchArguments":[]},{"pwStepLine":9,"gherkinStepLine":6,"keywordType":"Outcome","textWithKeyword":"Then the browser displays the generated input and action button","stepMatchArguments":[]},{"pwStepLine":10,"gherkinStepLine":7,"keywordType":"Action","textWithKeyword":"When I enter a fresh number and press the rendered calculate button","stepMatchArguments":[]},{"pwStepLine":11,"gherkinStepLine":8,"keywordType":"Outcome","textWithKeyword":"Then the agent answers using that browser input and its saved instructions","stepMatchArguments":[]}]},
]; // bdd-data-end