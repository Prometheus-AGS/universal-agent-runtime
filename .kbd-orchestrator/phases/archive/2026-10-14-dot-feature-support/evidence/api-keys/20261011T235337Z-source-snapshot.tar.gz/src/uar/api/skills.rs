//! Skills management API routes.
//!
//! REST endpoints for skills CRUD, matching configuration,
//! and per-agent skill bindings.

mod deployment_catalog;

pub use deployment_catalog::{
    SkillDeploymentCatalogState, build_router as build_deployment_catalog_router,
};

use crate::uar::domain::skills::{
    Skill, SkillExecutionConfig, SkillOrigin, SkillScope, SkillTriggers,
};
use crate::uar::runtime::skills::provenance::{PackProvenance, read_provenance};
use crate::uar::runtime::skills::service::{
    SkillMatchingConfig, SkillSelectionError, SkillService, SkillUpdate,
};
use axum::{
    Json, Router,
    extract::{Path, State},
    http::StatusCode,
    response::IntoResponse,
    routing::{delete, get, post, put},
};
use serde::{Deserialize, Serialize};
use std::path::PathBuf;
use std::sync::Arc;

fn selection_failure(error: SkillSelectionError) -> axum::response::Response {
    let (status, outcome) = match error {
        SkillSelectionError::Denied => (StatusCode::FORBIDDEN, "rejected"),
        SkillSelectionError::NotFound => (StatusCode::NOT_FOUND, "partial_possible"),
        SkillSelectionError::StorageMissing => (StatusCode::CONFLICT, "partial_possible"),
        SkillSelectionError::StoreUnavailable => (StatusCode::SERVICE_UNAVAILABLE, "unknown"),
        SkillSelectionError::FilesystemPartial => (StatusCode::SERVICE_UNAVAILABLE, "partial"),
    };
    (
        status,
        Json(serde_json::json!({ "error": error.to_string(), "outcome": outcome })),
    )
        .into_response()
}

/// Build the skills API router.
///
/// Mount under `/api/uar/skills` with `Arc<SkillService>` as state.
pub fn build_router() -> Router<Arc<SkillService>> {
    Router::new()
        // Skills CRUD
        .route("/", get(list_skills))
        .route("/", post(create_skill))
        .route("/{id}", get(get_skill))
        .route("/{id}", put(update_skill))
        .route("/{id}", delete(delete_skill))
        .route("/{id}/toggle", post(toggle_skill))
        .route("/match", get(match_skills))
        // Which pack version is loaded. See `provenance` module for why this
        // exists: UAR ran 359 commits stale and nothing could report it.
        .route("/provenance", get(get_provenance))
        .route("/update-check", get(check_for_update))
        .route("/update", post(initiate_update))
        .route("/refresh", post(refresh_skills))
        // Matching configuration
        .route("/import", post(import_skill_from_disk))
        .route("/config", get(get_config))
        .route("/config", put(set_config))
}

/// `GET /api/uar/skills/provenance` — which skill pack version is loaded.
///
/// Answers the question nothing could answer before `change-uhe-005`: UAR ran
/// for two months on a pack 359 commits stale, exposing 161 skills where the
/// pack shipped 220, and no surface reported it.
///
/// `loaded_skill_count` is what this runtime actually registered;
/// `pack.skill_count` is what the pack believes it ships. **A mismatch between
/// them is the drift signal** — which is why both are returned rather than one
/// "skills" number that could quietly be either.
async fn get_provenance(State(service): State<Arc<SkillService>>) -> impl IntoResponse {
    let root = crate::uar::runtime::skills::builtin_loader::builtin_dir();
    // SKILLS.md lives one level above the `skills/` directory.
    let pack_root = root.parent().unwrap_or(&root).to_path_buf();
    let pack = read_provenance(&pack_root);
    let loaded = match service.get_skills_checked().await {
        Ok(skills) => skills.len(),
        Err(error) => return selection_failure(error),
    };

    let drift = match pack.skill_count {
        Some(n) if n != loaded => Some(format!("pack reports {n} skills, runtime loaded {loaded}")),
        Some(_) => None,
        // Unknown is NOT "no drift": an older pack states nothing, and saying
        // "no drift" there would be a false assurance.
        None => Some("pack version unknown — cannot compare".to_string()),
    };

    Json(ProvenanceResponse {
        pack,
        loaded_skill_count: loaded,
        drift,
    })
    .into_response()
}

/// Provenance response body.
#[derive(Debug, Serialize)]
struct ProvenanceResponse {
    /// What the pack says about itself.
    pack: PackProvenance,
    /// What this runtime actually loaded.
    loaded_skill_count: usize,
    /// Human-readable drift note, or `null` when pack and runtime agree.
    drift: Option<String>,
}

/// Build the agent-skills binding router.
///
/// Mount under `/api/uar/agents` with `Arc<SkillService>` as state.
pub fn build_agent_skills_router() -> Router<Arc<SkillService>> {
    Router::new()
        .route("/{agent_id}/skills", get(get_agent_skills))
        .route("/{agent_id}/skills", put(set_agent_skills))
        .route("/{agent_id}/skills/{skill_id}", post(add_agent_skill))
        .route("/{agent_id}/skills/{skill_id}", delete(remove_agent_skill))
}

// --- Request / Response types ---

#[derive(Serialize)]
struct SkillResponse {
    skill_id: String,
    title: String,
    description: String,
    version: String,
    enabled: bool,
    origin: SkillOrigin,
    provider_id: String,
    triggers: crate::uar::domain::skills::SkillTriggers,
    preferred_tools: Vec<String>,
    prompt_overlay: String,
    execution_config: SkillExecutionConfig,
}

impl From<crate::uar::domain::skills::Skill> for SkillResponse {
    fn from(s: crate::uar::domain::skills::Skill) -> Self {
        Self {
            skill_id: s.skill_id,
            title: s.title,
            description: s.description,
            version: s.version,
            enabled: s.enabled,
            origin: s.origin,
            provider_id: s.provider_id,
            triggers: s.triggers,
            preferred_tools: s.preferred_tools,
            prompt_overlay: s.prompt_overlay,
            execution_config: s.execution_config,
        }
    }
}

/// Request body for creating a skill dynamically via the API.
#[derive(Deserialize)]
struct CreateSkillRequest {
    /// Human-readable skill name. The `skill_id` is derived from this.
    name: String,
    #[serde(default = "default_version")]
    version: String,
    description: String,
    #[serde(default)]
    triggers: SkillTriggers,
    #[serde(default)]
    prompt_overlay: String,
    #[serde(default)]
    preferred_tools: Vec<String>,
    #[serde(default = "default_enabled")]
    enabled: bool,
    #[serde(default)]
    execution_config: SkillExecutionConfig,
}

fn default_version() -> String {
    "1.0.0".to_string()
}

fn default_enabled() -> bool {
    true
}

#[derive(Deserialize)]
struct ToggleRequest {
    enabled: bool,
    #[serde(default)]
    scope: Option<SkillScope>,
}

#[derive(Deserialize, Default)]
struct UpdateSkillRequest {
    version: Option<String>,
    title: Option<String>,
    description: Option<String>,
    triggers: Option<SkillTriggers>,
    prompt_overlay: Option<String>,
    preferred_tools: Option<Vec<String>>,
    enabled: Option<bool>,
    #[serde(default)]
    execution_config: Option<SkillExecutionConfig>,
}

#[derive(Deserialize)]
struct MatchQuery {
    q: String,
    agent_id: Option<String>,
    conversation_id: Option<String>,
}

#[derive(Deserialize)]
struct AgentSkillsRequest {
    skill_ids: Vec<String>,
}

// --- Import from disk types ---

#[derive(Debug, Deserialize)]
pub struct SkillImportRequest {
    pub path: String,
}

#[derive(Debug, Serialize)]
pub struct SkillImportResponse {
    pub parsed: ParsedSkillData,
    pub validation: ImportValidation,
}

#[derive(Debug, Serialize)]
pub struct ParsedSkillData {
    pub name: String,
    #[serde(skip_serializing_if = "Option::is_none")]
    pub title: Option<String>,
    pub description: String,
    pub version: String,
    pub triggers: SkillTriggers,
    pub prompt_overlay: String,
    pub source: String,
    pub source_path: String,
    pub references: Vec<String>,
    pub detected_format: String,
}

#[derive(Debug, Serialize)]
pub struct ImportValidation {
    pub valid: bool,
    pub warnings: Vec<String>,
}

// --- Skills endpoints ---

async fn list_skills(State(service): State<Arc<SkillService>>) -> axum::response::Response {
    match service.get_skills_checked().await {
        Ok(skills) => {
            Json(skills.into_iter().map(SkillResponse::from).collect::<Vec<_>>()).into_response()
        }
        Err(error) => selection_failure(error),
    }
}

async fn create_skill(
    State(service): State<Arc<SkillService>>,
    Json(req): Json<CreateSkillRequest>,
) -> impl IntoResponse {
    let skill_id = req.name.to_lowercase().replace(' ', "-");
    let skill = Skill {
        skill_id,
        version: req.version,
        title: req.name,
        description: req.description,
        triggers: req.triggers,
        prompt_overlay: req.prompt_overlay,
        preferred_tools: req.preferred_tools,
        mcp_config: None,
        constraints: Default::default(),
        enabled: req.enabled,
        provider_id: "api".to_string(),
        execution_config: req.execution_config,
        kind: Default::default(),
        origin: Default::default(),
        ..Default::default()
    };

    match service.create_skill(skill).await {
        Ok(created) => (StatusCode::CREATED, Json(SkillResponse::from(created))).into_response(),
        Err(e) => (
            StatusCode::INTERNAL_SERVER_ERROR,
            Json(serde_json::json!({ "error": format!("{e:?}") })),
        )
            .into_response(),
    }
}

async fn get_skill(
    State(service): State<Arc<SkillService>>,
    Path(id): Path<String>,
) -> impl IntoResponse {
    let skills = match service.get_skills_checked().await {
        Ok(skills) => skills,
        Err(error) => return selection_failure(error),
    };
    match skills.into_iter().find(|s| s.skill_id == id) {
        Some(skill) => Json(SkillResponse::from(skill)).into_response(),
        None => StatusCode::NOT_FOUND.into_response(),
    }
}

async fn delete_skill(
    State(service): State<Arc<SkillService>>,
    Path(id): Path<String>,
) -> impl IntoResponse {
    match service.delete_skill_permanent(&id).await {
        Ok(true) => StatusCode::NO_CONTENT.into_response(),
        Ok(false) => StatusCode::NOT_FOUND.into_response(),
        Err(e) => {
            let msg = format!("{e}");
            if msg.contains("system_skill_immutable") {
                (
                    StatusCode::CONFLICT,
                    Json(serde_json::json!({
                        "error": "system_skill_immutable",
                        "message": "System skill cannot be removed.",
                    })),
                )
                    .into_response()
            } else {
                (
                    StatusCode::INTERNAL_SERVER_ERROR,
                    Json(serde_json::json!({ "error": format!("{e:?}") })),
                )
                    .into_response()
            }
        }
    }
}

async fn update_skill(
    State(service): State<Arc<SkillService>>,
    Path(id): Path<String>,
    Json(req): Json<UpdateSkillRequest>,
) -> impl IntoResponse {
    let patch = SkillUpdate {
        version: req.version,
        title: req.title,
        description: req.description,
        triggers: req.triggers,
        prompt_overlay: req.prompt_overlay,
        preferred_tools: req.preferred_tools,
        enabled: req.enabled,
        execution_config: req.execution_config,
    };

    match service.update_skill(&id, patch).await {
        Ok(Some(skill)) => Json(SkillResponse::from(skill)).into_response(),
        Ok(None) => StatusCode::NOT_FOUND.into_response(),
        Err(e) => {
            let msg = format!("{e}");
            if msg.contains("system_skill_immutable") {
                (
                    StatusCode::CONFLICT,
                    Json(serde_json::json!({
                        "error": "system_skill_immutable",
                        "message": "System skill cannot be edited; disable it instead.",
                    })),
                )
                    .into_response()
            } else {
                (
                    StatusCode::INTERNAL_SERVER_ERROR,
                    Json(serde_json::json!({ "error": format!("{e:?}") })),
                )
                    .into_response()
            }
        }
    }
}

async fn toggle_skill(
    State(service): State<Arc<SkillService>>,
    Path(id): Path<String>,
    Json(req): Json<ToggleRequest>,
) -> impl IntoResponse {
    match service
        .set_scoped_enabled_checked(&id, req.scope.unwrap_or(SkillScope::Global), req.enabled)
        .await
    {
        Ok(()) => StatusCode::OK.into_response(),
        Err(error) => selection_failure(error),
    }
}

async fn match_skills(
    State(service): State<Arc<SkillService>>,
    axum::extract::Query(params): axum::extract::Query<MatchQuery>,
) -> axum::response::Response {
    let snapshot = match service.matching_snapshot().await {
        Ok(snapshot) => snapshot,
        Err(error) => return selection_failure(error),
    };
    let matched = snapshot
        .match_skills_scoped(
            &params.q,
            params.agent_id.as_deref(),
            params.conversation_id.as_deref(),
        )
        .await;
    Json(
        matched
            .accepted_skills()
            .into_iter()
            .map(SkillResponse::from)
            .collect::<Vec<_>>(),
    )
    .into_response()
}

async fn refresh_skills(State(service): State<Arc<SkillService>>) -> impl IntoResponse {
    match service.refresh().await {
        Ok(skills) => Json(serde_json::json!({
            "count": skills.len(),
            "skills": skills.into_iter().map(SkillResponse::from).collect::<Vec<_>>(),
        }))
        .into_response(),
        Err(e) => (
            StatusCode::INTERNAL_SERVER_ERROR,
            Json(serde_json::json!({ "error": format!("{e:?}") })),
        )
            .into_response(),
    }
}

// --- Import from disk endpoint ---

async fn import_skill_from_disk(Json(req): Json<SkillImportRequest>) -> impl IntoResponse {
    let dir_path = PathBuf::from(&req.path);

    // Validate directory exists
    if !dir_path.is_dir() {
        return (
            StatusCode::BAD_REQUEST,
            Json(serde_json::json!({ "error": "Path is not a directory or does not exist" })),
        )
            .into_response();
    }

    let mut warnings: Vec<String> = Vec::new();

    // Scan for known subdirectories
    let mut references: Vec<String> = Vec::new();
    for subdir in &["references", "scripts", "assets"] {
        let sub = dir_path.join(subdir);
        if sub.is_dir() {
            if let Ok(entries) = std::fs::read_dir(&sub) {
                for entry in entries.flatten() {
                    if let Some(name) = entry.file_name().to_str() {
                        references.push(format!("{subdir}/{name}"));
                    }
                }
            }
        }
    }

    // Detect format and parse
    let skill_md = dir_path.join("SKILL.md");
    let skills_md = dir_path.join("SKILLS.md");
    let claude_dir = dir_path.join(".claude");

    if skill_md.is_file() {
        // agentskills.io format
        match std::fs::read_to_string(&skill_md) {
            Ok(content) => {
                let (frontmatter, body) = parse_frontmatter(&content);
                let name = frontmatter.get("name").cloned().unwrap_or_else(|| {
                    warnings
                        .push("Missing 'name' in frontmatter; using directory name".to_string());
                    dir_path
                        .file_name()
                        .and_then(|n| n.to_str())
                        .unwrap_or("unknown")
                        .to_string()
                });
                let description = frontmatter.get("description").cloned().unwrap_or_else(|| {
                    warnings.push("Missing 'description' in frontmatter".to_string());
                    String::new()
                });
                let version = frontmatter
                    .get("version")
                    .cloned()
                    .unwrap_or_else(|| "1.0.0".to_string());

                // Parse triggers from frontmatter
                let triggers = parse_triggers_from_frontmatter(&frontmatter);

                let parsed = ParsedSkillData {
                    name,
                    title: frontmatter.get("title").cloned(),
                    description,
                    version,
                    triggers,
                    prompt_overlay: body,
                    source: "filesystem".to_string(),
                    source_path: req.path.clone(),
                    references,
                    detected_format: "agentskills-io".to_string(),
                };

                let validation = ImportValidation {
                    valid: warnings.is_empty()
                        || warnings.iter().all(|w| !w.contains("Missing 'name'")),
                    warnings,
                };

                Json(SkillImportResponse { parsed, validation }).into_response()
            }
            Err(e) => (
                StatusCode::INTERNAL_SERVER_ERROR,
                Json(serde_json::json!({ "error": format!("Failed to read SKILL.md: {e}") })),
            )
                .into_response(),
        }
    } else if skills_md.is_file() {
        // Bundle catalog format
        match std::fs::read_to_string(&skills_md) {
            Ok(content) => {
                let (frontmatter, body) = parse_frontmatter(&content);
                let name = frontmatter.get("name").cloned().unwrap_or_else(|| {
                    dir_path
                        .file_name()
                        .and_then(|n| n.to_str())
                        .unwrap_or("unknown-bundle")
                        .to_string()
                });

                warnings.push(
                    "Detected bundle catalog (SKILLS.md); contains multiple skills".to_string(),
                );

                let parsed = ParsedSkillData {
                    name,
                    title: frontmatter.get("title").cloned(),
                    description: frontmatter.get("description").cloned().unwrap_or_default(),
                    version: frontmatter
                        .get("version")
                        .cloned()
                        .unwrap_or_else(|| "1.0.0".to_string()),
                    triggers: SkillTriggers::default(),
                    prompt_overlay: body,
                    source: "filesystem".to_string(),
                    source_path: req.path.clone(),
                    references,
                    detected_format: "bundle-catalog".to_string(),
                };

                let validation = ImportValidation {
                    valid: true,
                    warnings,
                };

                Json(SkillImportResponse { parsed, validation }).into_response()
            }
            Err(e) => (
                StatusCode::INTERNAL_SERVER_ERROR,
                Json(serde_json::json!({ "error": format!("Failed to read SKILLS.md: {e}") })),
            )
                .into_response(),
        }
    } else if claude_dir.is_dir() {
        // Claude Code plugin format
        warnings.push("Detected Claude Code plugin format (.claude/ directory)".to_string());

        let name = dir_path
            .file_name()
            .and_then(|n| n.to_str())
            .unwrap_or("unknown-plugin")
            .to_string();

        let parsed = ParsedSkillData {
            name,
            title: None,
            description: "Claude Code plugin (auto-detected)".to_string(),
            version: "1.0.0".to_string(),
            triggers: SkillTriggers::default(),
            prompt_overlay: String::new(),
            source: "filesystem".to_string(),
            source_path: req.path.clone(),
            references,
            detected_format: "claude-code-plugin".to_string(),
        };

        let validation = ImportValidation {
            valid: true,
            warnings,
        };

        Json(SkillImportResponse { parsed, validation }).into_response()
    } else {
        (
            StatusCode::BAD_REQUEST,
            Json(serde_json::json!({
                "error": "No recognized skill format found. Expected SKILL.md, SKILLS.md, or .claude/ directory."
            })),
        )
            .into_response()
    }
}

/// Parse YAML frontmatter from a markdown file delimited by `---` markers.
///
/// Returns a map of key-value pairs and the markdown body.
fn parse_frontmatter(content: &str) -> (std::collections::HashMap<String, String>, String) {
    let mut map = std::collections::HashMap::new();
    let parts: Vec<&str> = content.splitn(3, "---").collect();

    if parts.len() < 3 {
        // No valid frontmatter; treat entire content as body
        return (map, content.to_string());
    }

    let yaml_section = parts[1].trim();
    let body = parts[2].trim().to_string();

    // Simple line-by-line key: value parsing
    for line in yaml_section.lines() {
        let line = line.trim();
        if line.is_empty() || line.starts_with('#') {
            continue;
        }
        if let Some((key, value)) = line.split_once(':') {
            let key = key.trim().to_string();
            let value = value
                .trim()
                .trim_matches('"')
                .trim_matches('\'')
                .to_string();
            if !key.is_empty() {
                map.insert(key, value);
            }
        }
    }

    (map, body)
}

/// Extract trigger keywords from frontmatter.
///
/// Supports simple comma-separated values in a `triggers` or `keywords` field.
fn parse_triggers_from_frontmatter(
    frontmatter: &std::collections::HashMap<String, String>,
) -> SkillTriggers {
    let keywords = frontmatter
        .get("keywords")
        .or_else(|| frontmatter.get("triggers"))
        .map(|v| {
            v.trim_matches('[')
                .trim_matches(']')
                .split(',')
                .map(|s| s.trim().trim_matches('"').trim_matches('\'').to_string())
                .filter(|s| !s.is_empty())
                .collect::<Vec<_>>()
        })
        .unwrap_or_default();

    let semantic = frontmatter.get("semantic").cloned();

    SkillTriggers { keywords, semantic }
}

// --- Config endpoints ---

async fn get_config(State(service): State<Arc<SkillService>>) -> Json<SkillMatchingConfig> {
    Json(service.get_matching_config().await)
}

async fn set_config(
    State(service): State<Arc<SkillService>>,
    Json(config): Json<SkillMatchingConfig>,
) -> StatusCode {
    service.set_matching_config(config).await;
    StatusCode::OK
}

// --- Agent-skills binding endpoints ---

async fn get_agent_skills(
    State(service): State<Arc<SkillService>>,
    Path(agent_id): Path<String>,
) -> axum::response::Response {
    match service.get_agent_skill_ids_checked(&agent_id).await {
        Ok(ids) => Json(ids).into_response(),
        Err(error) => selection_failure(error),
    }
}

async fn set_agent_skills(
    State(service): State<Arc<SkillService>>,
    Path(agent_id): Path<String>,
    Json(req): Json<AgentSkillsRequest>,
) -> axum::response::Response {
    match service
        .set_agent_skills_checked(&agent_id, req.skill_ids)
        .await
    {
        Ok(()) => StatusCode::OK.into_response(),
        Err(error) => selection_failure(error),
    }
}

async fn add_agent_skill(
    State(service): State<Arc<SkillService>>,
    Path((agent_id, skill_id)): Path<(String, String)>,
) -> axum::response::Response {
    match service
        .add_skill_to_agent_checked(&agent_id, &skill_id)
        .await
    {
        Ok(()) => StatusCode::CREATED.into_response(),
        Err(error) => selection_failure(error),
    }
}

async fn remove_agent_skill(
    State(service): State<Arc<SkillService>>,
    Path((agent_id, skill_id)): Path<(String, String)>,
) -> axum::response::Response {
    match service
        .remove_skill_from_agent_checked(&agent_id, &skill_id)
        .await
    {
        Ok(()) => StatusCode::NO_CONTENT.into_response(),
        Err(error) => selection_failure(error),
    }
}

// ---------------------------------------------------------------------------
// R5: update check and update initiation
// ---------------------------------------------------------------------------

/// `GET /update-check` — is a newer skill pack available?
///
/// Reports `up-to-date`, `behind`, or `unknown`. **A network failure is
/// `unknown`, never `up-to-date`** — see
/// [`update_check`](crate::uar::runtime::skills::update_check) for why that
/// distinction is load-bearing rather than pedantic.
///
/// Always returns `200`: "we could not tell you" is a successful answer to the
/// question asked, and surfacing it as a 5xx would push callers toward retry
/// loops for a condition that is often permanent (offline device, rate limit).
async fn check_for_update() -> impl IntoResponse {
    use crate::uar::runtime::skills::update_check;

    let root = crate::uar::runtime::skills::builtin_loader::builtin_dir();
    let pack_root = root.parent().unwrap_or(&root).to_path_buf();
    let local = read_provenance(&pack_root);
    let repo = update_check::default_repo();

    let status = update_check::check_for_update(&local, &repo).await;
    (
        StatusCode::OK,
        Json(serde_json::json!({
            "repo": repo,
            "local_commit": local.commit,
            "result": status,
        })),
    )
}

/// `POST /update` — initiate a pack update on desktop/server.
///
/// # Why this reports rather than executes, for now
///
/// Updating the pack means moving a git submodule the *host process is running
/// from*. Doing that under a live server risks the runtime reading a
/// half-updated tree, and the safe sequence (fetch → verify → swap → reload)
/// needs a restart boundary this endpoint does not own.
///
/// Rather than ship a command that half-works, this returns the exact steps and
/// the current status. **An endpoint that claims to have updated when it has
/// not is the same failure class as a check that reports `up-to-date` offline.**
///
/// Mobile hosts cannot run this at all — see `change-uhe-014`.
async fn initiate_update() -> impl IntoResponse {
    use crate::uar::runtime::skills::update_check;

    let root = crate::uar::runtime::skills::builtin_loader::builtin_dir();
    let pack_root = root.parent().unwrap_or(&root).to_path_buf();
    let local = read_provenance(&pack_root);
    let repo = update_check::default_repo();
    let status = update_check::check_for_update(&local, &repo).await;

    // Refuse to hand out update instructions we know are unnecessary or
    // unfounded. Acting on an `unknown` is how a user ends up "updating" to the
    // version they already have.
    let (code, actionable) = match &status {
        update_check::UpdateStatus::Behind { .. } => (StatusCode::OK, true),
        update_check::UpdateStatus::UpToDate { .. } => (StatusCode::OK, false),
        update_check::UpdateStatus::Unknown { .. } => (StatusCode::SERVICE_UNAVAILABLE, false),
    };

    let steps: Vec<String> = if actionable {
        vec![
            format!("git -C {} fetch origin", pack_root.display()),
            format!("git -C {} checkout origin/main", pack_root.display()),
            "restart the runtime so builtins reload from the new tree".to_string(),
        ]
    } else {
        Vec::new()
    };

    (
        code,
        Json(serde_json::json!({
            "repo": repo,
            "result": status,
            "actionable": actionable,
            "pack_root": pack_root.display().to_string(),
            "steps": steps,
            "note": "This endpoint reports the update path; it does not swap the \
                     tree under a live process. See change-uhe-013.",
        })),
    )
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn skill_response_exposes_lowercase_origin() {
        let skill = Skill {
            skill_id: "builtin::origin-proof".to_string(),
            origin: SkillOrigin::Builtin,
            ..Skill::default()
        };

        let response =
            serde_json::to_value(SkillResponse::from(skill)).expect("serialize response");
        assert_eq!(response["origin"], "builtin");
    }
}
