//! Scoped chat policy contracts and deterministic resolution.
//!
//! UAR owns policy resolution. Hosts submit intent at global, agent,
//! conversation, or turn scope; the runtime resolves one immutable policy before
//! it assembles context or exposes tools to a model.

use std::collections::{BTreeMap, BTreeSet};
use std::sync::Arc;

use schemars::JsonSchema;
use serde::{Deserialize, Serialize};

use crate::uar::context::ContextStrategy;
use crate::uar::domain::artifact::AgentArtifact;
use crate::uar::persistence::PersistenceLayer;
use crate::uar::settings::manager::SettingsManager;

/// Current serialized policy schema version.
pub const RUN_POLICY_VERSION: u32 = 1;

fn default_policy_owner() -> String {
    crate::session::ANONYMOUS_SESSION_OWNER.to_string()
}

/// Durable conversation-scoped policy record owned by UAR persistence.
#[derive(Debug, Clone, PartialEq, Serialize, Deserialize, JsonSchema)]
pub struct ConversationPolicyRecord {
    /// Authenticated user that owns the conversation.
    #[serde(default = "default_policy_owner")]
    pub owner_id: String,
    /// Stable conversation/session identifier.
    pub conversation_id: String,
    /// Versioned requested policy.
    pub policy: RunPolicy,
    /// Last update timestamp.
    pub updated_at: chrono::DateTime<chrono::Utc>,
}

impl ConversationPolicyRecord {
    /// Create a record using the current UTC timestamp.
    #[must_use]
    pub fn new(conversation_id: impl Into<String>, policy: RunPolicy) -> Self {
        Self::new_for_user(
            crate::session::ANONYMOUS_SESSION_OWNER,
            conversation_id,
            policy,
        )
    }

    /// Create an owner-scoped record using the current UTC timestamp.
    #[must_use]
    pub fn new_for_user(
        owner_id: impl Into<String>,
        conversation_id: impl Into<String>,
        policy: RunPolicy,
    ) -> Self {
        Self {
            owner_id: owner_id.into(),
            conversation_id: conversation_id.into(),
            policy,
            updated_at: chrono::Utc::now(),
        }
    }
}

/// User-visible execution mode for a chat run.
#[derive(Debug, Clone, Copy, Default, PartialEq, Eq, Serialize, Deserialize, JsonSchema)]
#[serde(rename_all = "snake_case")]
pub enum ChatMode {
    /// Use a registered host-owned local model through UAR governance.
    Local,
    /// Use UAR's protected orchestrator with its configured provider route.
    #[default]
    Uar,
    /// Execute a selected persisted UAR agent artifact.
    Agent,
}

/// How a scope selects resources from the set allowed by its parent scope.
#[derive(Debug, Clone, Copy, Default, PartialEq, Eq, Serialize, Deserialize, JsonSchema)]
#[serde(rename_all = "snake_case")]
pub enum SelectionMode {
    /// Preserve the parent scope's selection.
    #[default]
    Inherit,
    /// Let UAR choose a subset from the eligible resources at run time.
    Auto,
    /// Make every eligible resource available.
    All,
    /// Make no resource of this kind available.
    None,
    /// Make only the named eligible resources available.
    Selected,
}

/// Resource-selection intent at one policy scope.
#[derive(Debug, Clone, Default, PartialEq, Eq, Serialize, Deserialize, JsonSchema)]
pub struct ResourceSelection {
    /// Selection behavior.
    #[serde(default)]
    pub mode: SelectionMode,
    /// Stable resource identifiers used when `mode` is `selected`.
    #[serde(default)]
    pub ids: Vec<String>,
    /// Resource identifiers explicitly denied at this scope.
    #[serde(default)]
    pub denied_ids: Vec<String>,
}

impl ResourceSelection {
    /// Construct a selected-resource policy with deterministic identifiers.
    #[must_use]
    pub fn selected(ids: impl IntoIterator<Item = String>) -> Self {
        let ids = ids
            .into_iter()
            .collect::<BTreeSet<_>>()
            .into_iter()
            .collect();
        Self {
            mode: SelectionMode::Selected,
            ids,
            denied_ids: Vec::new(),
        }
    }
}

/// Explicit provider/model route requested by a policy scope.
#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize, JsonSchema)]
pub struct ModelRoute {
    /// Provider registry identifier.
    pub provider_id: String,
    /// Provider-local model identifier.
    pub model_id: String,
}

/// Tool-call approval constraint.
#[derive(Debug, Clone, Copy, Default, PartialEq, Eq, Serialize, Deserialize, JsonSchema)]
#[serde(rename_all = "snake_case")]
pub enum ToolApprovalPolicy {
    /// Preserve the parent policy.
    #[default]
    Inherit,
    /// Let UAR governance decide whether approval is necessary.
    Auto,
    /// Require user approval for tool calls.
    Ask,
    /// Deny tool calls.
    Deny,
}

/// Versioned policy supplied at global, agent, conversation, or turn scope.
#[derive(Debug, Clone, PartialEq, Serialize, Deserialize, JsonSchema)]
pub struct RunPolicy {
    /// Serialized schema version.
    #[serde(default = "default_policy_version")]
    pub version: u32,
    /// Optional execution-mode override.
    #[serde(default)]
    pub chat_mode: Option<ChatMode>,
    /// Optional selected agent identifier.
    #[serde(default)]
    pub agent_id: Option<String>,
    /// Optional explicit provider/model route.
    #[serde(default)]
    pub model: Option<ModelRoute>,
    /// Eligible or selected skills.
    #[serde(default)]
    pub skills: ResourceSelection,
    /// Eligible or selected tool identifiers.
    #[serde(default)]
    pub tools: ResourceSelection,
    /// Eligible or selected MCP servers.
    #[serde(default)]
    pub mcp_servers: ResourceSelection,
    /// Eligible or selected knowledge bases.
    #[serde(default)]
    pub knowledge_bases: ResourceSelection,
    /// Eligible reusable Presentation templates. Legacy requests inherit.
    #[serde(default)]
    pub presentations: ResourceSelection,
    /// Optional memory enablement override.
    #[serde(default)]
    pub memory_enabled: Option<bool>,
    /// Optional prompt-caching override. `None` inherits from lower scopes.
    #[serde(default)]
    pub prompt_caching_enabled: Option<bool>,
    /// Optional message/context management strategy.
    #[serde(default)]
    pub context_strategy: Option<ContextStrategy>,
    /// Tool approval constraint.
    #[serde(default)]
    pub tool_approval: ToolApprovalPolicy,
}

const fn default_policy_version() -> u32 {
    RUN_POLICY_VERSION
}

impl Default for RunPolicy {
    fn default() -> Self {
        Self {
            version: RUN_POLICY_VERSION,
            chat_mode: None,
            agent_id: None,
            model: None,
            skills: ResourceSelection::default(),
            tools: ResourceSelection::default(),
            mcp_servers: ResourceSelection::default(),
            knowledge_bases: ResourceSelection::default(),
            presentations: ResourceSelection::default(),
            memory_enabled: None,
            prompt_caching_enabled: None,
            context_strategy: None,
            tool_approval: ToolApprovalPolicy::Inherit,
        }
    }
}

/// Convert a persisted agent artifact into its policy scope.
#[must_use]
pub fn policy_from_agent_artifact(agent: &AgentArtifact) -> RunPolicy {
    let chat_mode = if matches!(agent.id.as_str(), "default-agent" | "orchestrator-agent") {
        ChatMode::Uar
    } else {
        ChatMode::Agent
    };
    let skills = if agent.policy.skills.prefer.is_empty() {
        ResourceSelection {
            mode: SelectionMode::Auto,
            ..ResourceSelection::default()
        }
    } else {
        ResourceSelection::selected(agent.policy.skills.prefer.clone())
    };
    let tools = if agent.policy.tools.allow.is_empty() {
        ResourceSelection {
            mode: SelectionMode::Auto,
            denied_ids: agent.policy.tools.deny.clone(),
            ..ResourceSelection::default()
        }
    } else if agent.policy.tools.allow.iter().any(|tool| tool == "*") {
        // Agent artifacts historically use `*` as a wildcard.  The scoped
        // policy contract represents that intent explicitly as `all`; treating
        // it as a literal selected tool empties the eligible set and prevents
        // every native/MCP tool from reaching the model.
        ResourceSelection {
            mode: SelectionMode::All,
            denied_ids: agent.policy.tools.deny.clone(),
            ..ResourceSelection::default()
        }
    } else {
        ResourceSelection {
            denied_ids: agent.policy.tools.deny.clone(),
            ..ResourceSelection::selected(agent.policy.tools.allow.clone())
        }
    };
    let knowledge_bases = if agent.memory.kb.enabled {
        if agent.memory.kb.knowledge_bases.is_empty() {
            ResourceSelection {
                mode: SelectionMode::Auto,
                ..ResourceSelection::default()
            }
        } else {
            ResourceSelection::selected(agent.memory.kb.knowledge_bases.clone())
        }
    } else {
        ResourceSelection {
            mode: SelectionMode::None,
            ..ResourceSelection::default()
        }
    };

    let default_provider = &agent.policy.provider.default;
    let model = (!default_provider.provider.trim().is_empty()
        && !default_provider.model.trim().is_empty())
    .then(|| ModelRoute {
        provider_id: default_provider.provider.clone(),
        model_id: default_provider.model.clone(),
    });
    let mut policy = RunPolicy {
        chat_mode: Some(chat_mode),
        agent_id: Some(agent.id.clone()),
        model,
        skills,
        tools,
        knowledge_bases,
        memory_enabled: Some(agent.memory.conversation.enabled),
        ..RunPolicy::default()
    };

    // Agent artifacts predate the shared scoped RunPolicy contract. Preserve
    // their stable schema while allowing KnowMe and other UAR clients to store
    // the complete agent-level policy (MCP servers, context strategy, approval,
    // and explicit deny lists) in the standard extension map.
    if let Some(extension) = agent.extensions.get("uar.run_policy")
        && let Ok(extended) = serde_json::from_value::<RunPolicy>(extension.clone())
    {
        if extended.chat_mode.is_some() {
            policy.chat_mode = extended.chat_mode;
        }
        if extended.agent_id.is_some() {
            policy.agent_id = extended.agent_id;
        }
        if extended.model.is_some() {
            policy.model = extended.model;
        }
        merge_resource_selection(&mut policy.skills, extended.skills);
        merge_resource_selection(&mut policy.tools, extended.tools);
        merge_resource_selection(&mut policy.mcp_servers, extended.mcp_servers);
        merge_resource_selection(&mut policy.knowledge_bases, extended.knowledge_bases);
        merge_resource_selection(&mut policy.presentations, extended.presentations);
        if extended.memory_enabled.is_some() {
            policy.memory_enabled = extended.memory_enabled;
        }
        if extended.context_strategy.is_some() {
            policy.context_strategy = extended.context_strategy;
        }
        if extended.tool_approval != ToolApprovalPolicy::Inherit {
            policy.tool_approval = extended.tool_approval;
        }
    }

    if agent
        .extensions
        .get("uar.run_policy")
        .is_some_and(|value| serde_json::from_value::<RunPolicy>(value.clone()).is_err())
    {
        // A malformed extension must not erase Presentation restrictions.
        policy.presentations.mode = SelectionMode::None;
    }
    policy
}

fn merge_resource_selection(target: &mut ResourceSelection, value: ResourceSelection) {
    if value.mode != SelectionMode::Inherit || !value.ids.is_empty() || !value.denied_ids.is_empty()
    {
        *target = value;
    }
}

/// Scope that supplied an effective policy value.
#[derive(
    Debug, Clone, Copy, PartialEq, Eq, PartialOrd, Ord, Serialize, Deserialize, JsonSchema,
)]
#[serde(rename_all = "snake_case")]
pub enum PolicyScope {
    /// Runtime-wide policy.
    Global,
    /// Selected agent policy.
    Agent,
    /// Persisted conversation policy.
    Conversation,
    /// One-run override.
    Turn,
    /// Compatibility behavior derived from existing runtime configuration.
    Legacy,
}

/// Resources enabled by configuration and available on the current runtime.
#[derive(Debug, Clone, Default, PartialEq, Eq)]
pub struct PolicyUniverse {
    /// Enabled skill identifiers.
    pub skills: BTreeSet<String>,
    /// Enabled tool identifiers.
    pub tools: BTreeSet<String>,
    /// Enabled and platform-compatible MCP server identifiers.
    pub mcp_servers: BTreeSet<String>,
    /// Enabled knowledge-base identifiers.
    pub knowledge_bases: BTreeSet<String>,
    /// Enabled templates accessible to the verified owner.
    pub presentations: BTreeSet<String>,
    /// Secret-free admission failures carried into the effective-policy receipt.
    pub presentation_warnings: Vec<String>,
}

/// Resolved selection for one resource kind.
#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize, JsonSchema)]
pub struct EffectiveResourceSelection {
    /// Runtime behavior after resolution.
    pub mode: SelectionMode,
    /// Eligible resource identifiers in deterministic order.
    pub ids: Vec<String>,
    /// Last non-inherited scope that affected the selection.
    pub source: PolicyScope,
}

fn legacy_presentation_selection() -> EffectiveResourceSelection {
    // A persisted pre-Presentation policy cannot acquire newly created resources.
    EffectiveResourceSelection {
        mode: SelectionMode::None,
        ids: Vec::new(),
        source: PolicyScope::Legacy,
    }
}

/// Secret-free, immutable policy used to execute one run.
#[derive(Debug, Clone, PartialEq, Serialize, Deserialize, JsonSchema)]
pub struct EffectiveRunPolicy {
    /// Serialized schema version.
    pub version: u32,
    /// Effective chat mode.
    pub chat_mode: ChatMode,
    /// Effective agent identifier, when applicable.
    pub agent_id: Option<String>,
    /// Effective provider/model route, when explicitly selected.
    pub model: Option<ModelRoute>,
    /// Effective skill eligibility.
    pub skills: EffectiveResourceSelection,
    /// Effective tool eligibility.
    pub tools: EffectiveResourceSelection,
    /// Effective MCP server eligibility.
    pub mcp_servers: EffectiveResourceSelection,
    /// Effective knowledge-base eligibility.
    pub knowledge_bases: EffectiveResourceSelection,
    /// Owner-accessible Presentation eligibility frozen at admission.
    #[serde(default = "legacy_presentation_selection")]
    pub presentations: EffectiveResourceSelection,
    /// Whether governed memory participates in the run.
    pub memory_enabled: bool,
    /// Whether explicit provider prompt caching participates in the run.
    pub prompt_caching_enabled: bool,
    /// Effective context strategy.
    pub context_strategy: ContextStrategy,
    /// Effective tool approval constraint.
    pub tool_approval: ToolApprovalPolicy,
    /// Source scope for scalar policy fields.
    pub provenance: BTreeMap<String, PolicyScope>,
    /// Missing, disabled, or conflicting selections that were safely excluded.
    pub warnings: Vec<String>,
}

/// Provider name of the built-in tool that lets the model activate a skill.
pub const ACTIVATE_SKILL_TOOL: &str = "activate_skill";

/// Provider name of the built-in tool that searches deferred MCP tools. Kept
/// equal to `native_skills::search_tools::SEARCH_TOOLS_NAME`; the domain layer
/// cannot depend on the runtime layer, and a test pins the two together.
pub const SEARCH_TOOLS_TOOL: &str = "search_tools";

impl EffectiveRunPolicy {
    /// Whether a built-in model-control tool (`Exposure::ModelOnly`, such as
    /// `activate_skill`, the team tools or the agent controls) may be offered
    /// to the model on this run.
    ///
    /// These tools used to be exempt from tool policy, so `activate_skill`
    /// was offered even when the agent allowed no skills, and the team and
    /// agent controls survived an allowlist that did not name them. They now
    /// follow the restriction that covers them:
    ///
    /// - `activate_skill` follows the skill policy: refused for
    ///   `skills.mode: none`, and for `selected` with nothing selected.
    /// - `search_tools` is never refused. It only searches MCP tools the
    ///   policy has already admitted, so refusing it removes no capability and
    ///   would leave deferred tools undiscoverable.
    /// - Every other model-control tool follows the tool policy: when
    ///   `tools.mode` is `none` or `selected`, it needs its name or id in the
    ///   allowlist.
    ///
    /// With no restriction (`auto`, `all`, `inherit`) nothing changes.
    #[must_use]
    pub fn allows_model_control_tool(&self, name: &str, id: &str) -> bool {
        if name == SEARCH_TOOLS_TOOL {
            return true;
        }
        if name == ACTIVATE_SKILL_TOOL {
            return match self.skills.mode {
                SelectionMode::None => false,
                SelectionMode::Selected => !self.skills.ids.is_empty(),
                SelectionMode::Inherit | SelectionMode::Auto | SelectionMode::All => true,
            };
        }
        match self.tools.mode {
            SelectionMode::None | SelectionMode::Selected => self
                .tools
                .ids
                .iter()
                .any(|allowed| allowed == name || allowed == id),
            SelectionMode::Inherit | SelectionMode::Auto | SelectionMode::All => true,
        }
    }
}

/// Input required to resolve one immutable effective policy.
#[derive(Debug, Clone, Default)]
pub struct PolicyResolutionInput {
    /// Runtime-wide policy.
    pub global: Option<RunPolicy>,
    /// Selected agent policy.
    pub agent: Option<RunPolicy>,
    /// Persisted conversation policy.
    pub conversation: Option<RunPolicy>,
    /// One-run policy override.
    pub turn: Option<RunPolicy>,
    /// Enabled and runtime-compatible resources.
    pub universe: PolicyUniverse,
    /// Compatibility mode used when no scope selects one.
    pub default_chat_mode: ChatMode,
    /// Compatibility context strategy.
    pub default_context_strategy: ContextStrategy,
    /// Compatibility agent identifier.
    pub default_agent_id: Option<String>,
    /// Compatibility provider/model route.
    pub default_model: Option<ModelRoute>,
    /// System-wide prompt-caching default outside the scoped run-policy record.
    pub default_prompt_caching_enabled: bool,
}

/// Resolve one run policy using deny-safe, non-widening scope precedence.
#[must_use]
pub fn resolve_run_policy(input: PolicyResolutionInput) -> EffectiveRunPolicy {
    let scopes = [
        (PolicyScope::Global, input.global.as_ref()),
        (PolicyScope::Agent, input.agent.as_ref()),
        (PolicyScope::Conversation, input.conversation.as_ref()),
        (PolicyScope::Turn, input.turn.as_ref()),
    ];

    let mut provenance = BTreeMap::new();
    let mut chat_mode = input.default_chat_mode;
    let mut agent_id = input.default_agent_id;
    let mut model = input.default_model;
    let mut context_strategy = input.default_context_strategy;
    let mut memory_enabled = true;
    let mut prompt_caching_enabled = input.default_prompt_caching_enabled;
    let mut memory_locked_off = false;
    let mut tool_approval = ToolApprovalPolicy::Auto;

    for (scope, policy) in scopes {
        let Some(policy) = policy else { continue };
        if let Some(value) = policy.chat_mode {
            chat_mode = value;
            provenance.insert("chat_mode".into(), scope);
        }
        if let Some(value) = &policy.agent_id {
            agent_id = Some(value.clone());
            provenance.insert("agent_id".into(), scope);
        }
        if let Some(value) = &policy.model {
            model = Some(value.clone());
            provenance.insert("model".into(), scope);
        }
        if let Some(value) = &policy.context_strategy {
            context_strategy = value.clone();
            provenance.insert("context_strategy".into(), scope);
        }
        if let Some(value) = policy.memory_enabled {
            if !value {
                memory_enabled = false;
                memory_locked_off = true;
                provenance.insert("memory_enabled".into(), scope);
            } else if !memory_locked_off {
                memory_enabled = true;
                provenance.insert("memory_enabled".into(), scope);
            }
        }
        if scope != PolicyScope::Agent
            && let Some(value) = policy.prompt_caching_enabled
        {
            prompt_caching_enabled = value;
            provenance.insert("prompt_caching_enabled".into(), scope);
        }
        if approval_rank(policy.tool_approval) > approval_rank(tool_approval) {
            tool_approval = policy.tool_approval;
            provenance.insert("tool_approval".into(), scope);
        }
    }

    provenance
        .entry("chat_mode".into())
        .or_insert(PolicyScope::Legacy);
    provenance
        .entry("agent_id".into())
        .or_insert(PolicyScope::Legacy);
    provenance
        .entry("model".into())
        .or_insert(PolicyScope::Legacy);
    provenance
        .entry("context_strategy".into())
        .or_insert(PolicyScope::Legacy);
    provenance
        .entry("memory_enabled".into())
        .or_insert(PolicyScope::Legacy);
    provenance
        .entry("prompt_caching_enabled".into())
        .or_insert(PolicyScope::Global);
    provenance
        .entry("tool_approval".into())
        .or_insert(PolicyScope::Legacy);

    let mut warnings = input.universe.presentation_warnings.clone();
    let skills = resolve_resources(
        &input.universe.skills,
        &scopes,
        |policy| &policy.skills,
        "skill",
        &mut warnings,
    );
    let tools = resolve_resources(
        &input.universe.tools,
        &scopes,
        |policy| &policy.tools,
        "tool",
        &mut warnings,
    );
    let mcp_servers = resolve_resources(
        &input.universe.mcp_servers,
        &scopes,
        |policy| &policy.mcp_servers,
        "MCP server",
        &mut warnings,
    );
    let knowledge_bases = resolve_resources(
        &input.universe.knowledge_bases,
        &scopes,
        |policy| &policy.knowledge_bases,
        "knowledge base",
        &mut warnings,
    );
    let presentations = resolve_resources(
        &input.universe.presentations,
        &scopes,
        |policy| &policy.presentations,
        "Presentation",
        &mut warnings,
    );

    EffectiveRunPolicy {
        version: RUN_POLICY_VERSION,
        chat_mode,
        agent_id,
        model,
        skills,
        tools,
        mcp_servers,
        knowledge_bases,
        presentations,
        memory_enabled,
        prompt_caching_enabled,
        context_strategy,
        tool_approval,
        provenance,
        warnings,
    }
}

/// Transport-free inputs shared by the service and embedded resolvers.
///
/// Both the Axum `AppState` path and the in-process `RunManager` path build this
/// context from the components they already own (a settings manager, a resolved
/// [`PolicyUniverse`], and a default context strategy) so that policy resolution
/// runs through one shared core with no dependency on a web framework.
#[derive(Debug)]
pub struct PolicyResolutionContext<'a> {
    /// Runtime-wide settings source for the Global scope (`run_policy.global`).
    pub settings_manager: Option<&'a SettingsManager>,
    /// Resources enabled and available on the current runtime.
    pub universe: PolicyUniverse,
    /// Compatibility context strategy used when no scope selects one.
    pub default_context_strategy: ContextStrategy,
}

/// Resolve the effective policy for a conversation and turn using the full
/// Global → Agent → Conversation → Turn precedence.
///
/// This is the transport-free core shared by the HTTP service path and the
/// embedded runtime. It reads the Global scope from `run_policy.global` via the
/// supplied [`SettingsManager`], derives the Agent scope from `agent`, applies the
/// caller-resolved `conversation` scope, and applies `turn` last. When no settings
/// manager is available the Global scope is simply absent, which is the
/// backward-compatible agent+conversation behavior.
///
/// The conversation scope is passed in (not loaded here) because callers differ in
/// where a conversation policy lives: the service path also consults an in-memory
/// session map, while the embedded path uses [`load_persisted_conversation_policy`].
/// The resolution itself delegates to [`resolve_run_policy`], so identical inputs
/// always yield an identical [`EffectiveRunPolicy`] regardless of caller.
pub async fn resolve_effective_run_policy_core(
    ctx: PolicyResolutionContext<'_>,
    agent: &AgentArtifact,
    conversation: Option<RunPolicy>,
    turn: Option<RunPolicy>,
) -> EffectiveRunPolicy {
    let agent_default = &agent.policy.provider.default;
    let default_model = (!agent_default.provider.trim().is_empty()
        && !agent_default.model.trim().is_empty())
    .then(|| ModelRoute {
        provider_id: agent_default.provider.clone(),
        model_id: agent_default.model.clone(),
    });
    let mut universe = ctx.universe;
    let global = match ctx.settings_manager {
        Some(manager) => match manager
            .get_typed_for_admission::<RunPolicy>("run_policy.global")
            .await
        {
            Ok(policy) => policy,
            Err(error) => {
                tracing::warn!(%error, "failed to load global run policy; Presentation access is closed");
                universe.presentations.clear();
                universe.presentation_warnings.push(
                    "Global policy could not be loaded; Presentation access is closed".into(),
                );
                None
            }
        },
        None => None,
    };
    let default_prompt_caching_enabled = match ctx.settings_manager {
        Some(manager) => manager
            .get_typed::<bool>("prompt_caching.enabled")
            .await
            .map_err(|error| {
                tracing::warn!(%error, "failed to load global prompt-caching setting; using Off");
                error
            })
            .ok()
            .flatten()
            .unwrap_or(false),
        None => false,
    };
    let agent_policy = policy_from_agent_artifact(agent);
    resolve_run_policy(PolicyResolutionInput {
        global,
        agent: Some(agent_policy),
        conversation,
        turn,
        universe,
        default_chat_mode: ChatMode::Agent,
        default_context_strategy: ctx.default_context_strategy,
        default_agent_id: Some(agent.id.clone()),
        default_model,
        default_prompt_caching_enabled,
        ..PolicyResolutionInput::default()
    })
}

/// Load the durable conversation-scoped policy from persistence, if present.
///
/// Returns `None` when persistence is absent, the record is missing, or the load
/// fails (a load error is logged and treated as "inherit"). Callers that also
/// maintain an in-memory conversation policy (e.g. the service path) resolve that
/// fallback themselves and pass the result as the conversation scope.
pub async fn load_persisted_conversation_policy(
    persistence: Option<&Arc<dyn PersistenceLayer>>,
    owner_id: &str,
    conversation_id: &str,
) -> Option<RunPolicy> {
    let persistence = persistence?;
    match persistence
        .load_conversation_policy(owner_id, conversation_id)
        .await
    {
        Ok(Some(record)) => Some(record.policy),
        Ok(None) => None,
        Err(error) => {
            tracing::warn!(%error, %conversation_id, "failed to load conversation policy");
            None
        }
    }
}

/// Read a verified principal's conversation policy with non-destructive legacy fallback.
/// The boolean reports a principal-scoped row, including an explicit reset marker.
/// Legacy subject-only rows preserve old settings, never Presentation selections.
///
/// # Errors
/// Propagates storage failures and rejects a mismatched host owner stamp.
pub(crate) async fn load_owner_scoped_conversation_policy(
    persistence: &dyn PersistenceLayer,
    owner_id: &str,
    conversation_id: &str,
    owner: Option<&crate::uar::runtime::actor::messages::ActorOwner>,
) -> anyhow::Result<(Option<RunPolicy>, bool)> {
    if let Some(owner) = owner {
        anyhow::ensure!(
            owner.user_id() == owner_id,
            "Conversation policy owner mismatch"
        );
        let key = owner.presentation_owner_key();
        if let Some(record) = persistence
            .load_principal_conversation_policy(&key, conversation_id)
            .await?
        {
            anyhow::ensure!(
                record.owner_id == key,
                "Conversation policy partition mismatch"
            );
            // A reset shadows legacy data without deleting another tenant's fallback.
            let policy = (record.policy != RunPolicy::default()).then_some(record.policy);
            return Ok((policy, true));
        }
    }
    let legacy = persistence
        .load_conversation_policy(owner_id, conversation_id)
        .await?
        .map(|record| {
            let mut policy = record.policy;
            policy.presentations = ResourceSelection::default();
            policy
        });
    Ok((legacy, false))
}

fn approval_rank(value: ToolApprovalPolicy) -> u8 {
    match value {
        ToolApprovalPolicy::Inherit | ToolApprovalPolicy::Auto => 0,
        ToolApprovalPolicy::Ask => 1,
        ToolApprovalPolicy::Deny => 2,
    }
}

fn resolve_resources(
    universe: &BTreeSet<String>,
    scopes: &[(PolicyScope, Option<&RunPolicy>); 4],
    field: impl Fn(&RunPolicy) -> &ResourceSelection,
    label: &str,
    warnings: &mut Vec<String>,
) -> EffectiveResourceSelection {
    let mut eligible = universe.clone();
    let mut mode = SelectionMode::Auto;
    let mut source = PolicyScope::Legacy;
    let mut open = true;

    for (scope, policy) in scopes {
        let Some(policy) = policy else { continue };
        let selection = field(policy);
        let denied = selection
            .denied_ids
            .iter()
            .cloned()
            .collect::<BTreeSet<_>>();
        eligible = eligible
            .difference(&denied)
            .cloned()
            .collect::<BTreeSet<_>>();
        if !denied.is_empty() {
            open = false;
            source = *scope;
        }
        match selection.mode {
            SelectionMode::Inherit => {}
            SelectionMode::None => {
                eligible.clear();
                mode = SelectionMode::None;
                source = *scope;
                open = false;
            }
            SelectionMode::All | SelectionMode::Auto => {
                // Lower scopes cannot widen a set narrowed or denied above them.
                mode = if open {
                    selection.mode
                } else if eligible.is_empty() {
                    SelectionMode::None
                } else {
                    SelectionMode::Selected
                };
                source = *scope;
            }
            SelectionMode::Selected => {
                let requested = selection.ids.iter().cloned().collect::<BTreeSet<_>>();
                for missing in requested.difference(universe) {
                    warnings.push(format!("{label} '{missing}' is unavailable"));
                }
                for excluded in requested
                    .intersection(universe)
                    .filter(|id| !eligible.contains(*id))
                {
                    warnings.push(format!(
                        "{label} '{excluded}' was excluded by scope restrictions"
                    ));
                }
                eligible = eligible
                    .intersection(&requested)
                    .cloned()
                    .collect::<BTreeSet<_>>();
                mode = SelectionMode::Selected;
                source = *scope;
                open = false;
            }
        }
    }

    if !open && matches!(mode, SelectionMode::All | SelectionMode::Auto) {
        mode = if eligible.is_empty() {
            SelectionMode::None
        } else {
            SelectionMode::Selected
        };
    }

    EffectiveResourceSelection {
        mode,
        ids: eligible.into_iter().collect(),
        source,
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    fn universe() -> PolicyUniverse {
        PolicyUniverse {
            skills: ["alpha", "beta", "gamma"].map(str::to_string).into(),
            tools: ["read", "search"].map(str::to_string).into(),
            mcp_servers: ["files", "search"].map(str::to_string).into(),
            knowledge_bases: ["personal", "work"].map(str::to_string).into(),
            presentations: BTreeSet::new(),
            presentation_warnings: Vec::new(),
        }
    }

    fn input() -> PolicyResolutionInput {
        PolicyResolutionInput {
            universe: universe(),
            default_chat_mode: ChatMode::Uar,
            default_context_strategy: ContextStrategy::Auto,
            default_agent_id: Some("orchestrator-agent".into()),
            default_model: Some(ModelRoute {
                provider_id: "openai".into(),
                model_id: "gpt-test".into(),
            }),
            ..PolicyResolutionInput::default()
        }
    }

    #[test]
    fn presentation_scopes_intersect_and_lower_all_never_restores_exclusions() {
        let selection = |mode, ids: &[&str], denied: &[&str]| RunPolicy {
            presentations: ResourceSelection {
                mode,
                ids: ids.iter().map(|id| (*id).into()).collect(),
                denied_ids: denied.iter().map(|id| (*id).into()).collect(),
            },
            ..Default::default()
        };
        for lower_mode in [
            SelectionMode::Auto,
            SelectionMode::All,
            SelectionMode::Inherit,
            SelectionMode::Selected,
        ] {
            let result = resolve_run_policy(PolicyResolutionInput {
                universe: PolicyUniverse {
                    presentations: ["a", "b", "c"].map(str::to_owned).into(),
                    ..Default::default()
                },
                global: Some(selection(SelectionMode::Selected, &["a", "b"], &[])),
                agent: Some(selection(SelectionMode::Selected, &["b", "c"], &[])),
                conversation: Some(selection(lower_mode, &["a", "b", "c"], &[])),
                turn: Some(selection(SelectionMode::All, &[], &[])),
                ..Default::default()
            });
            assert_eq!(result.presentations.ids, vec!["b"]);
            assert_eq!(result.presentations.mode, SelectionMode::Selected);
        }
        let denied = resolve_run_policy(PolicyResolutionInput {
            universe: PolicyUniverse {
                presentations: ["a", "b"].map(str::to_owned).into(),
                ..Default::default()
            },
            global: Some(selection(SelectionMode::Inherit, &[], &["b"])),
            turn: Some(selection(SelectionMode::Selected, &["b", "missing"], &[])),
            ..Default::default()
        });
        assert!(denied.presentations.ids.is_empty());
        assert!(
            denied
                .warnings
                .iter()
                .any(|warning| warning.contains("'missing' is unavailable"))
        );
        assert!(
            denied
                .warnings
                .iter()
                .any(|warning| warning.contains("'b' was excluded"))
        );
    }

    #[test]
    fn legacy_persisted_effective_policy_does_not_acquire_presentations() {
        let current = resolve_run_policy(PolicyResolutionInput {
            universe: PolicyUniverse {
                presentations: ["new-template".into()].into(),
                ..Default::default()
            },
            ..Default::default()
        });
        let mut historical = serde_json::to_value(current).unwrap();
        historical.as_object_mut().unwrap().remove("presentations");
        let restored: EffectiveRunPolicy = serde_json::from_value(historical).unwrap();
        assert_eq!(restored.presentations.mode, SelectionMode::None);
        assert!(restored.presentations.ids.is_empty());
        assert_eq!(restored.presentations.source, PolicyScope::Legacy);
    }

    #[test]
    fn conversation_selection_narrows_agent_resources() {
        let agent = RunPolicy {
            skills: ResourceSelection::selected(["alpha".into(), "beta".into()]),
            ..RunPolicy::default()
        };
        let conversation = RunPolicy {
            skills: ResourceSelection::selected(["beta".into(), "gamma".into()]),
            ..RunPolicy::default()
        };
        let effective = resolve_run_policy(PolicyResolutionInput {
            agent: Some(agent),
            conversation: Some(conversation),
            ..input()
        });

        assert_eq!(effective.skills.ids, vec!["beta"]);
        assert_eq!(effective.skills.source, PolicyScope::Conversation);
    }

    #[test]
    fn lower_scope_cannot_reenable_parent_none() {
        let global = RunPolicy {
            mcp_servers: ResourceSelection {
                mode: SelectionMode::None,
                ids: vec![],
                denied_ids: vec![],
            },
            ..RunPolicy::default()
        };
        let turn = RunPolicy {
            mcp_servers: ResourceSelection {
                mode: SelectionMode::All,
                ids: vec![],
                denied_ids: vec![],
            },
            ..RunPolicy::default()
        };
        let effective = resolve_run_policy(PolicyResolutionInput {
            global: Some(global),
            turn: Some(turn),
            ..input()
        });

        assert!(effective.mcp_servers.ids.is_empty());
    }

    #[test]
    fn unavailable_resources_warn_without_broadening() {
        let conversation = RunPolicy {
            knowledge_bases: ResourceSelection::selected(["missing".into()]),
            ..RunPolicy::default()
        };
        let effective = resolve_run_policy(PolicyResolutionInput {
            conversation: Some(conversation),
            ..input()
        });

        assert!(effective.knowledge_bases.ids.is_empty());
        assert_eq!(
            effective.warnings,
            vec!["knowledge base 'missing' is unavailable"]
        );
    }

    #[test]
    fn memory_and_approval_constraints_only_tighten() {
        let global = RunPolicy {
            memory_enabled: Some(false),
            tool_approval: ToolApprovalPolicy::Ask,
            ..RunPolicy::default()
        };
        let turn = RunPolicy {
            memory_enabled: Some(true),
            tool_approval: ToolApprovalPolicy::Auto,
            ..RunPolicy::default()
        };
        let effective = resolve_run_policy(PolicyResolutionInput {
            global: Some(global),
            turn: Some(turn),
            ..input()
        });

        assert!(!effective.memory_enabled);
        assert_eq!(effective.tool_approval, ToolApprovalPolicy::Ask);
    }

    #[test]
    fn legacy_defaults_are_backward_compatible() {
        let effective = resolve_run_policy(input());

        assert_eq!(effective.chat_mode, ChatMode::Uar);
        assert_eq!(effective.skills.ids, vec!["alpha", "beta", "gamma"]);
        assert_eq!(effective.context_strategy, ContextStrategy::Auto);
        assert!(effective.warnings.is_empty());
    }

    #[test]
    fn legacy_policy_without_prompt_caching_inherits() {
        let policy: RunPolicy =
            serde_json::from_value(serde_json::json!({})).expect("legacy policy deserializes");
        assert_eq!(policy.prompt_caching_enabled, None);
    }

    #[test]
    fn prompt_caching_uses_session_then_turn_and_ignores_agent_scope() {
        let effective = resolve_run_policy(PolicyResolutionInput {
            agent: Some(RunPolicy {
                prompt_caching_enabled: Some(true),
                ..RunPolicy::default()
            }),
            conversation: Some(RunPolicy {
                prompt_caching_enabled: Some(false),
                ..RunPolicy::default()
            }),
            turn: Some(RunPolicy {
                prompt_caching_enabled: Some(true),
                ..RunPolicy::default()
            }),
            default_prompt_caching_enabled: false,
            ..input()
        });

        assert!(effective.prompt_caching_enabled);
        assert_eq!(
            effective.provenance.get("prompt_caching_enabled"),
            Some(&PolicyScope::Turn)
        );
    }

    #[test]
    fn agent_artifact_tool_wildcard_selects_every_available_tool() {
        let policy = policy_from_agent_artifact(&crate::uar::defaults::default_agent());
        assert_eq!(policy.tools.mode, SelectionMode::All);
        assert!(policy.tools.ids.is_empty());

        let effective = resolve_run_policy(PolicyResolutionInput {
            agent: Some(policy),
            ..input()
        });

        assert_eq!(effective.tools.mode, SelectionMode::All);
        assert_eq!(effective.tools.ids, vec!["read", "search"]);
        assert!(effective.warnings.is_empty());
    }

    #[test]
    fn agent_without_explicit_provider_inherits_the_runtime_model() {
        let mut agent = crate::uar::defaults::default_agent();
        agent.policy.provider.default.provider.clear();
        agent.policy.provider.default.model.clear();

        let policy = policy_from_agent_artifact(&agent);

        assert_eq!(policy.model, None);
    }

    #[test]
    fn agent_extension_supplies_complete_scoped_policy() {
        let mut agent = crate::uar::defaults::default_agent();
        agent.extensions.insert(
            "uar.run_policy".into(),
            serde_json::json!({
                "version": 1,
                "skills": { "mode": "selected", "ids": ["alpha"], "denied_ids": [] },
                "tools": { "mode": "inherit", "ids": [], "denied_ids": ["search"] },
                "mcp_servers": { "mode": "selected", "ids": ["files"], "denied_ids": [] },
                "knowledge_bases": { "mode": "none", "ids": [], "denied_ids": [] },
                "memory_enabled": false,
                "context_strategy": { "type": "sliding_window", "max_messages": 7 },
                "tool_approval": "ask"
            }),
        );

        let policy = policy_from_agent_artifact(&agent);
        assert_eq!(policy.skills.mode, SelectionMode::Selected);
        assert_eq!(policy.skills.ids, vec!["alpha"]);
        assert_eq!(policy.tools.denied_ids, vec!["search"]);
        assert_eq!(policy.mcp_servers.ids, vec!["files"]);
        assert_eq!(policy.knowledge_bases.mode, SelectionMode::None);
        assert_eq!(policy.memory_enabled, Some(false));
        assert_eq!(policy.tool_approval, ToolApprovalPolicy::Ask);
        assert!(matches!(
            policy.context_strategy,
            Some(ContextStrategy::SlidingWindow { max_messages: 7 })
        ));
    }
}
