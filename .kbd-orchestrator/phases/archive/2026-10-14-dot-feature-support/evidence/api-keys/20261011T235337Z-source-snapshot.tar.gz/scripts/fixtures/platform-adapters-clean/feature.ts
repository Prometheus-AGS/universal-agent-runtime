export const platformAdapterConsumer = true;
