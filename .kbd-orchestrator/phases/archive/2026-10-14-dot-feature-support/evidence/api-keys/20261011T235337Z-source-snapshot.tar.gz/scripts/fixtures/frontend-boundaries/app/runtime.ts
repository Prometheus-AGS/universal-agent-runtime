export const applicationRuntime = true;
